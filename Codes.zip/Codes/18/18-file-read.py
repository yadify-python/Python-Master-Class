f = open("test.py", "x")
#print(f.readline())
