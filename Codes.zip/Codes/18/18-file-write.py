f = open("python.txt", "w")     # a = append
f.write("Hello")                          
                              # w = overwrite