import os

if os.path.exists("test.txt"):
    os.remove("test.txt")
    print("File removed!")
else:
    print("File not found!")    