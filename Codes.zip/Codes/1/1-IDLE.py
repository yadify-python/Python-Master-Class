print("Hello")
print(8/4)
