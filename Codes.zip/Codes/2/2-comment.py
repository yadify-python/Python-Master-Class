a=2
b=3
c=a*b
d=a/b
#ضرب دو عدد
#zarbe 2 adad
"""this
is a
comment"""

print("zarb:",c,"taghsim:",d)
print("Hello world")
print('Hello world')
