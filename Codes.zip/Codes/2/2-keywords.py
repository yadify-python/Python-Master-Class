a=5
break=6
print(a*break)
