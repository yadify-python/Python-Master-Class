a=8
b=3
A=15
c=A*b
d=a/b
e=a**b



print("zarb: ",c,"taghsim: ",d,"tavan: ",e)

#punctuation
