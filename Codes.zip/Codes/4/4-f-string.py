age=36
text=f"My name is sara, I am: {age}"
#print(text)


a=f"The price is {2.5*96} dollars $ and the age:{age}"
print(a)
