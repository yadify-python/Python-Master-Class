#string

first_name="John"
last_name='Jackson'
a='12'
b='4'
#print('Your fname is:',first_name,'Your lname is:',last_name)
print(b+a)
