#index

a="Hello"

print(a.index("l"))
