#replace

x="Hello world!"

print(x.replace("o","8"))
print(x.replace(" ","-"))
