#slicing

a="Hello world!"
#print(a[2:7])
#print(a[:5])
#print(a[6:])

print(a[-6:-1])
print(a[-12:-7])


