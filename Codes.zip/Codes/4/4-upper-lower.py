a="HELLO WORLD"
b="hello world"


print(a.lower())   #lower-case
print(b.upper())   #upper-case
