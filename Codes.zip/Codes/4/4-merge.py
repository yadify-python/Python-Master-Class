a="salam"
b="chetory?"


print(a+' '+b)


x="My name is Erfan and I am: "
z=60
#print(x,z)
