"""set1={1, 2, 3}
tuple2=('a', 'b', 'c')"""

"""set3=set1.union(set2)    # set1 | set2
print(set3)"""
"""set1.update(tuple2)
print(set1)"""
set1={"BMW","Benz","Toyota","Mazda"}
set2={"206","Mazda","L90","Toyota"}

set3=set1 & set2    # set1 & set2
print(set3)