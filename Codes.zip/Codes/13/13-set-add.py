my_set={'John','Mary','Jackson','Adam'}  
#my_set.add("Sarah")
my_list=["Ali","Mohammad","Neda"]
my_set.add
my_set.update(my_list)
print(my_set)