my_set={'John','Mary','Jackson','Adam'} 

#my_set.remove('Ali')
#my_set.discard('Ali')
#my_set.pop()
#my_set.clear()
del my_set
print(my_set)