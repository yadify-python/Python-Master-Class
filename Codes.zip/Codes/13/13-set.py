my_set={'John','Mary',True,'Jackson','Adam','John',1}  
print(type(my_set))
#Unordered
#Unchangeable
#1=True   0=False