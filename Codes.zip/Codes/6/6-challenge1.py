#Hello and welcome


x=str(input("Enter the word: "))
y=x[-17:-8]
print(y)
