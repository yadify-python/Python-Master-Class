#casting

x=int(2.4)
#print(x)
y=float(8)
#print(y)
z=str(96)
#print(z)
a=float("Hello")
print(a)
