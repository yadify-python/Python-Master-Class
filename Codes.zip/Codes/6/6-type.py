

x="Hello"
#print(type(x))
y=["ali","maryam"]
#print(type(y))
z=True
print(type(z))
