x,y,z="BMW","Toyota","Mercedes-benz"
print(x)
print(y)
print(z)



a=b=c="Ford"


abc="Hello"
abc="Goodbye"
print(abc)


