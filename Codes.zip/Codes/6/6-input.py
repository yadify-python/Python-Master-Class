#input
x=float(input("Enter the first number: "))
y=float(input("Enter the second number: "))
name=str(input("What is your name?"))
print("Result:",x+y)
print("Your name",name)
