"""for x in range(6):
    print(x)
else:
    print("Finished!")    """


i=0
while i<6:
    print(i)
    i=i+1
else:
    print("Finished!")       