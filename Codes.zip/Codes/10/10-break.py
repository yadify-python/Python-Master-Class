i=1
while i<11:
    if i==5:
        break
    print(i)
    i=i+1