#range()

"""for x in range(5):
    print("Hello")"""

"""for i in range(84):
    print(i)  """  

for i in range(50,71,3) :
    print(i)   