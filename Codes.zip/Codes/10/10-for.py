word="Hello"
fruits=["apple","orange","watermelon"]

for i in fruits:
    print(i)