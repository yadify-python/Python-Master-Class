for i in range(10,21):
    if i==5:
        continue
    print(i)