i=1
while i<11:
    print(i)
    i+=1

i=i*2 #i*=2
    