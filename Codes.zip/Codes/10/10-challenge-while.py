i=100
while i>0:
    print(i,end="-")
    i=i-1