

while True :
    print("Select operator: ")
    print("1.Add")
    print("2.Subtract")
    print("3.Multiply")
    print("4.Divide")
    print("5.Exponentiate")
    print("6.Quit")
    operator = str(input("Enter the operator: "))
    if operator == "6":
        print("Calculator stopped!")
        break
    
    

    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
    

    if operator == "1" :
        print("Result: ", num1 + num2)
    elif operator == "2":
        print("Result: ", num1 - num2)
    elif operator=="3":
        print("Result: ",num1*num2)
    elif operator=="4":
        if num2==0:
            print("Error")
        else:    
            print("Result: ",num1/num2)
    elif operator=="5":
        print("Result: ",num1**num2)    
    else:
        print("The operator is invalid")    