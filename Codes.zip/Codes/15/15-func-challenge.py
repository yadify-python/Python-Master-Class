def rectangle (a, b) :
    area = a * b
    circumference = (a + b) * 2
    print ("Area: ", area, "Circumference: ", circumference)


lentgh = float (input ("Enter the lentgh: "))
height = float (input ("Enter the height: "))

rectangle(lentgh,height)