def rectangle (a, b) :
    area = a * b
    return area
    


lentgh = float (input ("Enter the lentgh: "))
height = float (input ("Enter the height: "))

area = rectangle(lentgh, height)
#print(rectangle(lentgh,height))
print(f'Area is: {area}')