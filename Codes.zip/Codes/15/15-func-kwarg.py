def person(**kwargs):
    sentence = ''
    for i in kwargs.values():
        sentence += i
    return sentence

print(person(fname = "Erfan", lname = " Rahaei", age= ' 27')) 



    