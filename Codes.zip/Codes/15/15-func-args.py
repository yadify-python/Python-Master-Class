"""numbers = [2,3,4]
print(sum(numbers))"""

def average(*args) :
    return sum(args) / len(args)

print(average(12, 5, 12, 45, 0, -9, 4.5))