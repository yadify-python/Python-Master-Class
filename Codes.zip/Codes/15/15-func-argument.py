def tavan(a,b):
    print(a*b)


tavan(2,3)   