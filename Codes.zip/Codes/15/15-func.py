def salam():
    print("Hello")


salam()    