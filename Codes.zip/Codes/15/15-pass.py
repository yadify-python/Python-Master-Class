def hello():
    pass

def goodbye():
    pass

a = 4
b = 5

if a>b :
    pass
