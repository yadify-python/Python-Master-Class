a=10


if a>=10:
    if a>15:
        print("more than 15")
    else:
        print("10-15")
else:
    print("Out of the range")        
