# and, or, not
a=2
b=3
c=10
if b>a and c>a:
    print("True")

if a>b or c>a:
    print("True")

if not a>b:
    print("Hello")