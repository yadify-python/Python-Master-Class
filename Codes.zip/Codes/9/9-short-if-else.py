a=3
b=3

print("Hello") if a>b else print("Goodbye")
