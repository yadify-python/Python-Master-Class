num=int(input("Enter the number: "))

if num>0:
    if num%2==0:
        print("Even and positive")
    else:
        print("odd and positive")
elif num==0:
    print("Even and zero")         
else:
    if num%2==0:
        print("Even and negative")       
    else:
        print("Odd and negative")