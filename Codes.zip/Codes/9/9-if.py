a=float(input("Enter the first number: "))
b=float(input("Enter the second number: "))
if b>a:
    print("b is greater than a")