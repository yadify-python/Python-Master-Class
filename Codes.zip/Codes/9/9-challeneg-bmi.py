weight=float(input("Enter the weight: "))
height=float(input("Enter the height: " ))
bmi=weight/(height**2)

if bmi<18.5:
    print(f"Your bmi is:{bmi} and your status is Underweight")
elif 18.5<=bmi<24.5:
    print(f"Your bmi is:{bmi} and your status is Normal") 
elif 24.5<=bmi<29.9:
    print(f"Your bmi is:{bmi} and your status is Overweight")
elif bmi>30:
    print(f"Your bmi is:{bmi} and your status is Obesity")           