class Students :
    def __init__(self, name, age, loc) :
        self.name = name
        self.age = age
        self.loc = loc

    def slm(self) :
        return f'Welcome {self.name}, you are: {self.age}'


class Teachers(Students) :
    def __init__(self, name, age, loc, salary):
        super().__init__(name, age, loc)
        self.salary = salary

    def infromation(self) :
        return f'Welcome {self.name}, your salary is: {self.salary}'    
    

o1 = Students("Erfan", 27, "Iran")
#print(o1.slm())  
o2 = Teachers('John', 32, 'France', '3500$')  
print(o2.slm())
print(o2.infromation())