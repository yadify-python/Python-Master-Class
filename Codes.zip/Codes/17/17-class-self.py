class Person :
    def __init__(self, fname, lname, age):
        self.fname = fname
        self.lname = lname
        self.age = age

    def birthday(self, number):
        print(f'Happy birthday {self.fname}, now you are {self.age + 1} and your number is: {number}')


       
o1 = Person("Erfan", "Rahaei", 27)
o1.birthday(9123456789)