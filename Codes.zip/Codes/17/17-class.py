class MyClass :
    pass

