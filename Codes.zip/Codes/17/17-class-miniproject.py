class Bank :
    def __init__(self, money) :
        self.money = money


    def mojoodi(self) :
        return self.money
    
    def bardasht(self, amount) :
        if self.money >= amount :
            self.money = self.money - amount
        else:
            print("Mojoodi kafi nist!")    

    def variz(self, amount) :
        self.money = self.money + amount


print("Welcome to the Bank!")
money = float(input("How much money do you have ? "))
o1 = Bank(money)
o1.variz(300)
o1.bardasht(900)
print(o1.mojoodi())

