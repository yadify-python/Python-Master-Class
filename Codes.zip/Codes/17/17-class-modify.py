class Person :
    def __init__(self, fname, lname, age):
        self.fname = fname
        self.lname = lname
        self.age = age
    def __str__(self) :
        return f'{self.fname}, {self.lname}'
    
    def birthday(self) :
        pass
       
o1 = Person("Erfan", "Rahaei", 27)
o1.age = 40
del o1.age
del o1
print(o1)