class Car :
    def __init__(self, brand, model, year, color) :
        self.brand = brand      #Property, Attribute
        self.model = model
        self.year = year
        self.color = color

    def slm(self) :
        print(f"Welcome, you have {self.brand}")   

class Person :
    def __init__(self, fname, lname, age):
        self.fname = fname
        self.lname = lname
        self.age = age

    def birthday(self):
        print(f'Happy birthday {self.fname}, now you are {self.age + 1}')    



p1 = Person("Erfan", "Rahaei", 27)
p1.birthday()
"""o1 = Car("Saipa", "Pride", 1402, "Black")  
o2 = Car("Benz", "AMG", 2024, "Green")      
o2.slm()"""