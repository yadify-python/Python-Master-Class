import tkinter as tk
from tkinter import messagebox

def bmi() :
    weight = e1.get()
    height = e2.get()
    bmi = float(weight) / (float(height) ** 2)
    messagebox.showinfo("BMI", f'Your BMI is: {bmi}')


window = tk.Tk()
window.title("BMI Calculator")
window.geometry("800x800")
frame = tk.Frame(master=window, width=1920, height=1080)
frame.pack()

l1 = tk.Label(master=frame, text="BMI Calculator", fg="green", bg="black", width=20, height=15)
l1.place(x=770, y=10)
l2 = tk.Label(master=frame, text="Weight", fg="red")
l2.place(x=550, y=300)
e1 = tk.Entry(master=frame)
e1.place(x=600, y=300)
l3 = tk.Label(master=frame, text="Height", fg="blue")
l3.place(x=950, y=300)
e2 = tk.Entry(master=frame)
e2.place(x=1000, y=300)
b1 = tk.Button(text="Show BMI!", fg="green", bg="black", command=bmi)
b1.place(x=800, y=400)

window.mainloop()