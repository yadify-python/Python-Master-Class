import tkinter as tk

window = tk.Tk()

l1 = tk.Label(text="Salam",foreground="#892c18",background="blue")
l2 = tk.Label(text="Goodbye",fg="green",bg="black",width=15,height=10)
e1 = tk.Entry(width=50)
t1 = tk.Text(bg="red",width=60)

l1.pack()
e1.pack()
t1.pack()
l2.pack()

window.mainloop()