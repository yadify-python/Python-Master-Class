import tkinter as tk
 
window = tk.Tk()

f1 = tk.Frame(master=window, width=800, height=500, bg="red")
f1.pack()
l1 = tk.Label(master=f1, text="Salam",foreground="#892c18",background="blue")
l2 = tk.Label(master=f1, text="Goodbye",fg="green",bg="black",width=15,height=10)
e1 = tk.Entry(master=f1, width=50)
b1 = tk.Button(master=f1, text="Click Here!", bg="black", fg="green")
b1.place(x=550,y=120)
l1.place(x=750,y=120)



window.mainloop()