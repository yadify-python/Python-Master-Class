import tkinter as tk
from tkinter import messagebox
window = tk.Tk()
#messagebox.showinfo("test", "This is a test")
#messagebox.showerror("Error", "This is an error")
#messagebox.showwarning("warning", "This is a warning")
messagebox.askquestion("question", "This is a question")

f1 = tk.Frame(master=window, width=1920, height=1080)
f1.pack()
l1 = tk.Label(master=f1, text="Salam",foreground="#892c18",background="blue")
l2 = tk.Label(master=f1, text="Goodbye",fg="green",bg="black",width=15,height=10)
e1 = tk.Entry(master=f1, width=50)
b1 = tk.Button(master=f1, text="Click Here!", bg="black", fg="green")
b1.place(x=550,y=120)
l1.place(x=750,y=120)



window.mainloop()