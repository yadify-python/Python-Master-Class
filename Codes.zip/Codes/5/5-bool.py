#boolean   bool



print(6==5)
print(10>20)
print(8>5)
