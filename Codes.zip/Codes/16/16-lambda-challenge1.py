l1 = [1, 2, 3, 4]
l2 = [5, 6, 7, 8]

x = map(lambda a, b : a ** b, l1, l2 )

print(list(x))