"""def num(a) :
    return a * 2"""


num = lambda a : a*2

print(num(6))