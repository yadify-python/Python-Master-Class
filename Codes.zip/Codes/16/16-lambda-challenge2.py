l1 = [1, 2, 3, 4]
l2 = [5, 6, 7, 8]
l1.extend(l2)
x = list(filter(lambda a : a % 2 == 0, l1))
y = list(map(lambda a : a * 2, x))
print(y)