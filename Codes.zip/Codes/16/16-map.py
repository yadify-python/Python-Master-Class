num = [5, 6, 9]

def square(a) :
    return a ** 2


x = map(square, num)

print(list(x))