num = [5, 8, 12, 17, 23, 50]

x = filter(lambda a : a % 2 == 0, num)

print(list(x))
