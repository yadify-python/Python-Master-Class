while True :   
    age = input("Enter your age: ")
    #print("Your age is:", int(age))

    try :
        print("Your age is:", int(age))
    except :
        print("Your entered data is incorrect!")
    else :
        print("Correct!")
        break   
"""    finally :
        print("Goodbye!")"""     