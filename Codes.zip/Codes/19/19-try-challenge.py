filename = "test.txt"

try :
    f = open(filename,"r")
except :
    print("Your filename is incorrect!")
else :
    print(f.read()) 
finally :
    print("Your file is closed")
    f.close()      