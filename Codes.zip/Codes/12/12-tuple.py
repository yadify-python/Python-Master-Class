aval=str(input("Enter your car: "))
dovom=str(input("Enter your car: "))
sevom=str(input("Enter your car: "))


my_tuple=tuple((aval,dovom,sevom))
print(my_tuple)