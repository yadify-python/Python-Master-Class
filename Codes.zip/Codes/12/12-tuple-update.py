my_tuple=('Benz','BMW','Toyota')

y=list(my_tuple)
#y.append("Fiat")
y.remove("BMW")
x=tuple(y)
print(x)

