my_tuple=('BMW','206','Benz','Toyota')
print(my_tuple[1:3])