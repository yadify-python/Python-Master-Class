my_tuple=('BMW','206','Benz','Toyota')
"""for x in my_tuple:
    print(x)"""

for i in range(len(my_tuple)):
    print(my_tuple[i])  