

"""tuple1=(1, 2, 3)
tuple2=('a', 'b', 'c')

tuple3=tuple1+tuple2
print(tuple3)"""

my_tuple=('BMW','206','Benz','Toyota')
x=my_tuple * 3
print(x)