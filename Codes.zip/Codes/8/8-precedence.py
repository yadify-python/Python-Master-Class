print((6+9)*(8-4))
print(100+6**4)
print(5+2-6+10)
