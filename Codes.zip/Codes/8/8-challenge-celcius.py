temperature=float(input("Enter the degree: "))
f=(temperature*9.5)+32
print("Degree in farenheit: ",f)