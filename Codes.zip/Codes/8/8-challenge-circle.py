radius=float(input("Enter the radius: "))
area=(radius**2)*3.14
circumference=radius*2*3.14
print("area:",area,"circumference:",circumference)