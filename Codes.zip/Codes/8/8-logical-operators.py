#print(5>2 or 6>3)
print (not(5>2 and 6<3))
