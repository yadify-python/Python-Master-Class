"""print(3>2)
print(3<2)
print(3>=2)
print(3<=2)"""
print(3!=2)