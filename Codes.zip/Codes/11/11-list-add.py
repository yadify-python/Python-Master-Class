cars=["BMW","Pride","Toyota","Honda"]

#append
cars.append("Benz")
#print(cars)

#insert
cars.insert(1,"206")
print(cars)