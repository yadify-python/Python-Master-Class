cars=["BMW","Pride","Toyota","Honda"]
if "Benz" in cars:
    print("You have a benz item in your list")
else:
    print("Error")    