#cars=["BMW",12,14.5,True,"Toyota","Benz","BMW"]
#print(len(cars))
#print(type(cars))

cars=list(("BMW",True,1234,"Benz"))
print(cars)