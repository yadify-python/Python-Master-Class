list1=["a", "b", "c"]
list2=[1, 2, 3]

"""list3=list2+list1
print(list3)"""

list2.extend(list1)
print(list2)