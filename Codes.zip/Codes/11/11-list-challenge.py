list1 = [54, 44, 27, 79, 91, 41]

list1.pop(4)
list1.insert(2,91)
list1.append(91)
print(list1)