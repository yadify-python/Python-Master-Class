my_list=["Ali","Sara","ali","Mohammad","Sanaz",]
numbers=[54,78,12,-8,120,14.5,250]
my_list.sort()
print(my_list)