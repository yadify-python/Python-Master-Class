my_list=["Ali","Sara","Mohammad","Sanaz"]

"""for x in my_list:
    print(x)"""

for x in range(len(my_list)) :
    print(my_list[x])

# list, tuple, set, dictionaries(dict)  ====> arrays, sequence data  