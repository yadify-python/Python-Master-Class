cars=["BMW","Pride","Toyota","Honda"]

cars[2]="206"
cars[1:3]=["206","L90"]