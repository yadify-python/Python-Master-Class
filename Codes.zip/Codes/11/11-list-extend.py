cars=["BMW","Pride","Toyota","Honda"]
colors=("Black","White","Red")

cars.extend(colors)
print(cars)