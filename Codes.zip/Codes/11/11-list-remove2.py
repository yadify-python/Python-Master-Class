cars=["BMW","Pride","Toyota","Honda","Pride"]
#cars.clear()
del cars
print(cars)