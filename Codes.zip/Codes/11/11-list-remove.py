cars=["BMW","Pride","Toyota","Honda","Pride"]
#cars.remove("Pride")
#cars.pop(1)
#cars.pop()
del cars[1]
print(cars)