my_dict= {
    "Brand":"Saipa",
    "Model":"Pride",
    "Year":1400,    
}


for x,y in my_dict.items():
    print(x,y)