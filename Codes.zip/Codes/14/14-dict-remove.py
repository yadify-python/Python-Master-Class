my_dict= {
    "Brand":"Saipa",
    "Model":"Pride",
    "Year":1400,    
}

#del my_dict["Model"]
#my_dict.pop("Model")
#my_dict.popitem()
#my_dict.clear()
del my_dict
print(my_dict)