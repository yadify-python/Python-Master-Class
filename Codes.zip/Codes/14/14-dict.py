"""my_dict= {
    "Brand":"Toyota",
    "Model":"Camry",
    "Year":2015,
    "Guarantee":2015
}
print(my_dict)
"""
car=dict(Brand="Benz",Model="AMG",Year=2012)
print(car)