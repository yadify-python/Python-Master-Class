my_dict= {
    "Brand":"Saipa",
    "Model":"Pride",
    "Year":1400,    
}

#my_dict["Color"] = "Black"

my_dict.update({"Color":"Black"})
print(my_dict)