my_dict= {
    "Brand":"Saipa",
    "Model":"Pride",
    "Year":1400,    
}

#my_dict["Year"]=1395
my_dict.update({"Year":1395})
print(my_dict)