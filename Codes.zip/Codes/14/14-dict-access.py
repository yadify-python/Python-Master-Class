my_dict= {
    "Brand":"Saipa",
    "Model":"Pride",
    "Year":1400,    
}
print(my_dict.get("Model"))
print(my_dict.keys())
print(my_dict.values())
print(my_dict.items())
