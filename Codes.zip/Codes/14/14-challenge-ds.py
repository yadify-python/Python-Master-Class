date = {'jan': 17, 'feb': 12, 'march': 17, 'April': 24, 'May':22, 'June': 13, 'july': 14, 'Aug': 24, 'Sept': 14}

x=date.values()
y=set(x)
print(y)